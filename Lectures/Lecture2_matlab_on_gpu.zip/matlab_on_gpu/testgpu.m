function testGPUInParfor()
spmd
    selectGPUDeviceForLab();
end

parfor i = 1:10
    % Each iteration will generate some data A
    A = rand(5);
    if selectGPUDeviceForLab()
        A = gpuArray(A);
        disp( 'Do it on the GPU' )
    else
        disp( 'Do it on the host' )
    end
    % replace the following line with whatever task you need to do
    S = sum(A,1);
    
    % Maybe collect back from GPU (gather is a no-op if not on the GPU)
    S = gather(S);
end

 
 
function ok = selectGPUDeviceForLab()
persistent hasGPU;

if isempty( hasGPU )
    devIdx = mod(labindex-1,gpuDeviceCount())+1;
    try
        dev = gpuDevice( devIdx );
        hasGPU = dev.DeviceSupported;
    catch %#ok
        hasGPU = false;
    end
end
ok = hasGPU;