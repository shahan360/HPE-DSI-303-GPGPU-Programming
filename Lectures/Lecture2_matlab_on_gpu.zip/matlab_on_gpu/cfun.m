Ga = rand(1000,'single');
Gfft = fft(Ga); 
Gb = (real(Gfft) + Ga) * 6;
whos