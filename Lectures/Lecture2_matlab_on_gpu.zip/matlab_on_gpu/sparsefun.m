x = [0 1 0 0 0; 0 0 0 0 1]
s = sparse(x)
g = gpuArray(s);   % g is a sparse gpuArray
gt = transpose(g); % gt is a sparse gpuArray
f = full(gt)
whos