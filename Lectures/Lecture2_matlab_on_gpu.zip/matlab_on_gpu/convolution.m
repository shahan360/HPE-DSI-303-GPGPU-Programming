	img = gpuArray(img);
	msk = padarray(msk,size(img)-size(msk),0,'post');
	msk = gpuArray(msk);
	I = fft2(img);
	M = fft2(msk,size(img,1),size(img,2));
	res = real(ifft2(I.*M));
	res = gather(res);