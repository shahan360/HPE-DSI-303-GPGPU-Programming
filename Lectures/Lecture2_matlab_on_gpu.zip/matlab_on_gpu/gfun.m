Ga = rand(1000,'single','gpuArray');
Gfft = fft(Ga); 
Gb = (real(Gfft) + Ga) * 6;
G = gather(Gb);
whos